package com.hehe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExternalizedConfigurationApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExternalizedConfigurationApplication.class, args);
	}
}
