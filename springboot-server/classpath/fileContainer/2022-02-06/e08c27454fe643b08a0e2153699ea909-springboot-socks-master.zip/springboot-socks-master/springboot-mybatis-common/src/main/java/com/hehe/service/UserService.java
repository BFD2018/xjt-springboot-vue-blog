package com.hehe.service;

import com.hehe.entity.User;
import com.hehe.tools.BaseService;

public interface UserService extends BaseService<User> {

}
