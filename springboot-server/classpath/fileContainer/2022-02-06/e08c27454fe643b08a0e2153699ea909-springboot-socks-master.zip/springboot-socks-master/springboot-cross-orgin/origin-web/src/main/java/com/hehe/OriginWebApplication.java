package com.hehe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OriginWebApplication {

    public static void main(String[] args) {
        SpringApplication.run(OriginWebApplication.class, args);
    }
}
